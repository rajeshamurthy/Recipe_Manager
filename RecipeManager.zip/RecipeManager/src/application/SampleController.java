package application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
public class SampleController {
	@FXML
    private TextField recipeNameField;   
    @FXML
    private ListView<String> recipeListView;    
    @FXML
    private TextArea recipeDetailsTextArea;   
    private ObservableList<String> recipeList;
    @FXML public void initialize() {
        recipeList = FXCollections.observableArrayList();
        recipeListView.setItems(recipeList);
    }    @FXML
    public void handleAddRecipe() {
        String recipeName = recipeNameField.getText();
        if (!recipeName.isEmpty()) {
            recipeList.add(recipeName);
            recipeNameField.clear();  // Clear the input after adding
        }}    @FXML
    public void showRecipeDetails() {
        String selectedRecipe = recipeListView.getSelectionModel().getSelectedItem();
        if (selectedRecipe != null) {
            recipeDetailsTextArea.setText("Details of recipe: " + selectedRecipe);
        }
    }	
}
